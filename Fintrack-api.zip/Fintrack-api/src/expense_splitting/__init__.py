"""Expense splitting package."""
